package WebServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.Medico;
import Model.Login;
import hospital.pronto.socorro.validarMedico;
import hospital.pronto.socorro.validarLogin;

@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet{
	private static final long serialVersionUID = -4893569432445997392L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		

		String login = req.getParameter("login");
		String senha = req.getParameter("senha");
		String crm = req.getParameter("crm");

		
		Medico medico = new Medico(login, senha, crm);
		Login secretaria = new Login(login, senha);
		
		medico = new validarMedico().autenticar(medico);
		secretaria = new validarLogin().autenticar(secretaria);
	
		
		if(medico != null) {
			req.getRequestDispatcher("Prontuario/ListaPaciente.jsp").forward(req, resp);
			Cookie cookie = new Cookie("medico.logado", medico.getCrm());
			resp.addCookie(cookie);
			
		}else if(secretaria != null) {
			
			req.getRequestDispatcher("Prontuario/prontuario.jsp").forward(req, resp);
			Cookie cookie1 = new Cookie("secretaria.logado", secretaria.getLogin());
			resp.addCookie(cookie1);
			
		}else{
			
			out.println("<h2 style=\"color:red;\"> LOGIN INVÁLIDO!</h2>");
		}	
		
		out.println("<a href=\"Login.Cadastro/index.jsp\"></a>");
		out.println("</body></html>");
		out.flush();
		out.close();
		}
	}
