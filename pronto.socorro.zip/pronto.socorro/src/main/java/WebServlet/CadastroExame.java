package WebServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import HospitalDAO.ExameDAO;

@WebServlet(urlPatterns="/prontuario")
public class CadastroExame extends HttpServlet {

	private static final long serialVersionUID = 8223367069764773160L;
	private ExameDAO exameDAO = new ExameDAO();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		
		String cpfPaciente = req.getParameter("cpfPaciente");
		String crm = req.getParameter("crm");
		String exame = req.getParameter("exame");
		String dataExame = req.getParameter("dataExame");
		
		exameDAO.addExame(
				crm, 
				cpfPaciente, 
				dataExame, 
				exame
		);
		
		req.getRequestDispatcher("/prontuario.jsp").forward(req, resp);
	}
}
