package Model;

public class Medico {

	private String login;
	private String senha;
	private String crm;
	
	public Medico(String login, String senha, String crm) {
		this.login = login;
		this.senha = senha;
		this.crm = crm;
	}
	
	public String getLogin() {
		return login;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String getCrm() {
		return crm;
	}
	
	public void setCrm(String crm) {
		this.crm = crm;
	}
	
	
}

