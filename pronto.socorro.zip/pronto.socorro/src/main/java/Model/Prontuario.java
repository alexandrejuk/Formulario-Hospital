package Model;

import Model.Medico;
import Model.Paciente;

public class Prontuario {

	private Medico medico;
	private Paciente paciente;
	private String dataExame;
	private String exame;

	public Prontuario(
		Medico medico, 
		Paciente paciente, 
		String dataExame, 
		String exame
	) {
		this.medico = medico;
		this.paciente = paciente;
		this.dataExame = dataExame;
		this.exame = exame;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public String getDataExame() {
		return dataExame;
	}

	public void setDataExame(String dataExame) {
		this.dataExame = dataExame;
	}


	public String geteExame() {
		return exame;
	}

	public void setExame(String exame) {
		this.exame = exame;
	}
}


