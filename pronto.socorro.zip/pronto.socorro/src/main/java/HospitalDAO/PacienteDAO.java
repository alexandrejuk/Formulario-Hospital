package HospitalDAO;

import java.util.ArrayList;

import Model.Paciente;

public class PacienteDAO {
	private static ArrayList<Paciente> paciente = new ArrayList<>();
	
	public void adicionar(Paciente p) {
		if(p != null) {
			paciente.add(p);
		}
	}
	
	public ArrayList<Paciente> consultarPacientes() {
		return paciente;
	}
	
	
	public Paciente cadPaciente(String nome) {
		for (Paciente p : paciente) {
				return p;
			
		}
		return null;
		
	}
	public Paciente consultarPorCPF(String cpf) {
		for(int i = 0; i < paciente.size(); i ++) {
			if(paciente.get(i).getCpf().equals(cpf)) {
				return paciente.get(i);
			}
		}
		return null;
	}
}