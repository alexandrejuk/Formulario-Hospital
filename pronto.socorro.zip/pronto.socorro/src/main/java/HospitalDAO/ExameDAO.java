package HospitalDAO;

import java.util.ArrayList;
import java.util.List;

import Model.Prontuario;
import Model.Medico;
import Model.Paciente;


public class ExameDAO {
	private static ArrayList<Prontuario> PRONTARIOS = new ArrayList<>();
	
	public Prontuario addExame(
		String crm, 
		String cpfPaciente, 
		String dataExame,  
		String Exame
	) {
		PacienteDAO pacienteDAO = new PacienteDAO();
		MedicoDAO medicoDAO = new MedicoDAO();
		Paciente paciente = pacienteDAO.consultarPorCPF(cpfPaciente);
		Medico medico = medicoDAO.consultarPorCRM(crm);		

		if (paciente != null && medico != null) {
			Prontuario novoExame = new Prontuario(
					medico, 
					paciente, 
					dataExame, 
					Exame);
			PRONTARIOS.add(novoExame);
			return novoExame;			
		}
		return null;
	}

	
	public List<Prontuario> procurarExameMedico(String crm){
		List<Prontuario> listaExame = new ArrayList<Prontuario>();
		for (int i = 0; i < PRONTARIOS.size(); i++) {
			if (PRONTARIOS.get(i).getMedico().getCrm().equals(crm)) {
				listaExame.add(PRONTARIOS.get(i));
			}
		}
		
		return listaExame;
		
	}
	
	
	public List<Prontuario> listarExames(){
		return PRONTARIOS;
		
	}	
}

