package HospitalDAO;

import java.util.ArrayList;

import Model.Login;

public class LoginDAO {
	
	private static ArrayList<Login> LOGIN = new ArrayList<>();
	
	static {
		LOGIN.add(new Login("secretaria", "secretaria"));
	}
	
	public void adiconar(Login l) {
		LOGIN.add(l);
	}
	
	public Login loginSecretaria(String login) {
		for (Login l : LOGIN) {
			if(l.getLogin().equals(login)) {
				return l;			
			}			
		}
		
		return null;
		
		}
	}

	