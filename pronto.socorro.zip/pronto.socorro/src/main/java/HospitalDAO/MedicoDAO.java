package HospitalDAO;

import java.util.ArrayList;
import java.util.List;

import Model.Medico;

public class MedicoDAO {

	private static ArrayList<Medico> MEDICO = new ArrayList<>();
	
	
	static {
		MEDICO.add(new Medico("medico", "medico", "123"));
	}
	
	public void adiconar(Medico m) {
		MEDICO.add(m);
	}
	
	public Medico loginMedico(String login) {
		for (Medico m : MEDICO) {
			if(m.getLogin().equals(login)) {
				return m;			
			}			
		}
		return null;	
	}
	
	
	public List<Medico> listaMedico(){
		return MEDICO;
	}
	
	
	public Medico consultarPorCRM(String crm) {
		for(int i = 0; i < MEDICO.size(); i ++) {
			if(MEDICO.get(i).getCrm().equals(crm)) {
				return MEDICO.get(i);
			}
		}
		return null;	
	}	
}
