package hospital.pronto.socorro;

import HospitalDAO.LoginDAO;
import Model.Login;

public class validarLogin {

	public Login autenticar(Login l) {
		Login secretaria = new LoginDAO().loginSecretaria(l.getLogin());
		if(secretaria == null) return null;
		if(!secretaria.getSenha().equals(l.getSenha())) return null;
		return secretaria;
	}	
}
