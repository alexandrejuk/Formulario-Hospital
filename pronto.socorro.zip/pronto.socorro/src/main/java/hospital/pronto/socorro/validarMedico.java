package hospital.pronto.socorro;

import HospitalDAO.MedicoDAO;
import Model.Medico;

public class validarMedico {
	
	public Medico autenticar(Medico m) {
		Medico medico = new MedicoDAO().loginMedico(m.getLogin());
		if(medico == null) return null;
		if(!medico.getSenha().equals(m.getSenha())) return null;
		return medico;
	}	
	
	public boolean validar(Medico m) {
			if (m.getLogin() == "medico" && m.getSenha() == "medico") {
				return true;
			}
			return false;
		}		
	}
	